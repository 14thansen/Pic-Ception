"""
File: picception.py

Changes the size of the images and organizes them.
"""

from tkinter import *
from tkinter import filedialog
import os
from images import Image, _root
from random import choice


class Picception(object):
	
	def __init__(self, minipics, bigpic, ratio):
		"""Collects information and variables needed to run program."""
		self._bigpic = Image(bigpic)
		self._bigpic.draw()
		_root.mainloop()
		self._minipics = []
		self._minifiles = minipics
		for pic in minipics:
			self._minipics.append(Image(pic))
		self._widthB = 0
		self._heightB = 0
		self._widthS = 0 
		self._heightS = 0
		self._ratio = ratio
		self.__getSize(self._ratio)
		for pic in range(len(self._minipics)):
			self._minipics[pic] = self.resize(self._minipics[pic])
		
		self._newImage = Image(self._widthB, self._heightB)
		
	def create(self):
		"""Places images to create the larger image."""
		self._newImage.draw()
		for y in range(0, self._heightB, self._heightS):
			for x in range(0, self._widthB, self._widthS):
				(r, g, b) = self.__getColor(self._bigpic, x, y, self._widthS, self._heightS)
				pic = choice(self._minipics)
				pic = self.__setColor(pic, (r, g, b))
				for yy in range(y, y + self._heightS):
					for xx in range(x, x + self._widthS):
						(r, g, b) = pic.getPixel(xx - x, yy - y)
						self._newImage.setPixel(xx, yy, (r, g, b))
			_root.update()
		"""
		self._bigpic = self._newImage
		self.__getSize(32)
		self._newImage = self.resize(self._newImage)
		self._newImage.draw()
		saveAs = filedialog.askdirectory(title = "Save As")
		saveAs += "/My Picception.gif"
		self._newImage.save(saveAs)
		"""
		os.system("screencapture screen.png")
		_root.mainloop()
		
		
	def __getSize(self, ratio):
		"""Determins the size of the small images."""
		self._widthB = self._bigpic.getWidth()
		self._heightB = self._bigpic.getHeight()
		if ratio == 0:
			ratio = self._widthB	
		self._widthS = self._widthB / ratio
		self._heightS = self._heightB / ratio
		if self._widthS < 1: self._widthS = 1
		if self._heightS < 1: self._heightS = 1
		
	def __getColor(self, pic, startx = None, starty = None, width = None, height = None):
		"""Scans the given section of an image and returns the average color of the area."""
		if width != None:
			rBucket = 0
			gBucket = 0
			bBucket = 0
			pixelCount = 0
			for y in range(starty, starty + height):
				if y >= self._heightB: break
				for x in range(startx, startx + width):
					if x >= self._widthB: break
					r, g, b = pic.getPixel(x, y)
					rBucket += r
					gBucket += g
					bBucket += b
					pixelCount += 1
		return (rBucket//pixelCount, gBucket//pixelCount, bBucket//pixelCount)

		
	def resize(self, image):
		"""Builds and returns a new image,
		the size determined by __getSize."""
		width = image.getWidth()
		height = image.getHeight()
		factorW = width / self._widthS
		factorH = height / self._heightS
		self._widthS = int(width // factorW)
		self._heightS = int(height // factorH)
		new = Image(self._widthS, self._heightS)
		oldY = 0
		newY = 0
		while oldY < height - int(factorH):
			oldX = 0
			newX = 0
			while oldX < width - int(factorW):
				oldP = image.getPixel(oldX, oldY)
				new.setPixel(newX, newY, oldP)
				oldX += int(factorW)
				newX += 1
			oldY += int(factorH)
			newY += 1
		return new
			
	def __setColor(self, pic, rgb):
		newpic = Image(pic.getWidth(), pic.getHeight())
		r = rgb[0]
		g = rgb[1]
		b = rgb[2]
		for y in range(pic.getHeight()):
			for x in range(pic.getWidth()):
				(rr, gg, bb) = pic.getPixel(x,y)
				rr += r
				gg += g
				bb += b
				if rr > 255: rr = 255
				if gg > 255: gg = 255
				if bb > 255: bb = 255
				newpic.setPixel(x, y, (rr, gg, bb))
		return newpic

"""				
def main():
	minipics = ["/Users/student/Downloads/pic-ception/test folder/bear.gif",
				"/Users/student/Downloads/pic-ception/test folder/brocoli.gif",
				"/Users/student/Downloads/pic-ception/test folder/bubble.gif",
				"/Users/student/Downloads/pic-ception/test folder/bush.gif",
				"/Users/student/Downloads/pic-ception/test folder/random_detail.gif",
				"/Users/student/Downloads/pic-ception/test folder/Random_picture_of_shark.gif",
				#"/Users/student/Downloads/pic-ception/test folder/weird lines.gif",
				"/Users/student/Downloads/pic-ception/test folder/weird nails.gif",
				"/Users/student/Downloads/pic-ception/test folder/wood animals.gif"]
	bigpic = "/Users/student/Downloads/pic-ception/test folder/brocoli.gif"
	
	Picception(minipics, bigpic, 64).create()
	
main()
"""
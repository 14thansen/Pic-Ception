"""
File: picGUI.py

A graphical layout for my pic-ception program. 
Gives the user a place to download files, and 
choose several other options for your collage.
"""

from tkinter import *
from tkinter import filedialog
import os

class picGUI(Frame):
	
	def __init__(self):
		"""Sets up the frame for the pic-ception program"""
		# Create the main frame
		self.root = Tk()
		Frame.__init__(self)
		self.master.title("Pic-Ception")
		self.grid(sticky = W+E+N+S)
		# Create a space for the instructions to appear
		self._instructionPane = Frame(self)
		self._instructionPane.grid(row = 0, column = 0)
		self.instructiontxt = 	"		  Welcome to 'Pic-Ception'!		\n"
		self.instructiontxt +=	"'Pic-Ception' is a collage generator that allows the user to put a lot of tiny pictures together to create one giant picture automatically. It is basically the greatest thing you've ever heard of, I know.\n"
		self.instructiontxt +=	"			Instructions:			\n"
		self.instructiontxt +=	"1. Choose the files that you wish to add as your small photos and place them in a single folder. The larger your large photo is and the more small photos you have the better your final product will look.\n"
		self.instructiontxt +=	"2. Convert those files to a .gif format (that is the only format the program will accept at this time). I recommend using this website (https://www.iloveimg.com/jpg-to-image/jpg-to-gif) because they allow you to convert and download multiple images at a time, but you may use any program that you like.\n"
		self.instructiontxt +=	"3. Choose the image that you would like your other images to create and convert that into a .gif file as well.\n"
		self.instructiontxt +=	"4. Upload your now converted images by clicking the appropriate browse buttons.\n"
		self._instructionLbl = Text(self._instructionPane, width = 65, height = 18, wrap = WORD)
		self._instructionLbl.insert("1.0", self.instructiontxt)
		self._instructionLbl.config(state=DISABLED)
		self._instructionLbl.grid(row = 0, column = 0)
		#picAlgorithm.testOutput()
		
		# Create the list box to show which files are being used
		self._listPane = Frame(self)
		self._listPane.grid(row = 1, column = 0)
		self._yScroll = Scrollbar(self._listPane, orient = VERTICAL)
		self._yScroll.grid(row = 0, column = 1, sticky = N+S, padx = (0, 5), pady = 5)
		self._xScroll = Scrollbar(self._listPane, orient = HORIZONTAL)
		self._xScroll.grid(row = 1, column = 0, sticky = E+W, pady = (0, 5), padx = 5)
		self._theList = Listbox(self._listPane,
								width = 50,
								height = 10,
								selectmode = BROWSE,
								yscrollcommand = self._yScroll.set,
								xscrollcommand = self._xScroll.set)
		self._theList.grid(row = 0, column = 0, sticky = E+W, pady = 5, padx = 5,
							ipady = 5, ipadx = 5)
		self._theList.insert(END, "Mini Images go here")
		self._yScroll["command"] = self._theList.yview
		self._xScroll["command"] = self._theList.xview
		
		# Create buttons for browsing and text box for main photo
		self._browsePane = Frame(self)
		self._browsePane.grid(row = 2, column = 0)
		self._miniBt = Button(self._browsePane, text = "Mini Images", command = self._browseM)
		self._miniBt.grid(row = 0, column = 3)
		self._bigBt = Button(self._browsePane, text = "Big Image", command = self._browseB)
		self._bigBt.grid(row = 0, column = 2)
		self._browseTxt = Text(self._browsePane, width = 7, height = 1)
		self._browseTxt.insert("1.0", "Browse:")
		self._browseTxt.config(state = DISABLED)
		self._browseTxt.grid(row = 0, column = 1)
		self._inputVar = StringVar()
		self._bigList = Entry(self._browsePane,
							  textvariable = self._inputVar,
							  width = 25)
		self._bigList.insert(0, "Big Image goes here")
		self._bigList.grid(row = 0, column = 0, pady = 5, padx = 5)
		
		self._nextBt = Button(self, text = "Next >>", width = 50, command = self._next, state = DISABLED)
		self._nextBt.grid(row = 3, column = 0)
		
		#Variables to save file names
		self._miniPics = []
		self._bigPic = ""	
		
		
	def _browseM(self):
		"""Opens the browse frame to find the mini photos and saves file names to a list."""
		tempdir = filedialog.askopenfilenames(initialdir="/", title='Please files', 
								filetypes = (("gif files", "*.gif"), ("all files", "*.*")))
		self._theList.delete(0)
		for item in tempdir:
			self._theList.insert(END, item)
			self._miniPics.append(item)
		if self._bigPic != "":
			self._nextBt.config(state = NORMAL)
			
	def _browseB(self):
		"""Opens the browse frame to find the large photo and saves file name."""
		self._bigPic = filedialog.askopenfilename(initialdir="/", title='Please files', 
								filetypes = (("gif files", "*.gif"), ("all files", "*.*")))
		self._bigList.delete(0, 100)
		self._bigList.insert(0, self._bigPic)
		if len(self._miniPics) > 0:
			self._nextBt.config(state = NORMAL)
		
	def _next(self):
		"""Closes the frame and opens the next one."""
		self.root.destroy()
		optionsPage(self._miniPics, self._bigPic)

class optionsPage(Frame):
	
	def __init__(self, minipics, bigpic):
		"""Sets up the frame for options page."""
		self._minipics = minipics
		self._bigpic = bigpic
		# Create the main frame
		self.root = Tk()
		Frame.__init__(self)
		self.master.title("Pic-Ception")
		self.grid(sticky = W+E+N+S)
		
		# Create a space for instructions
		self._instructionPane = Frame(self)
		self._instructionPane.grid(row = 0, column = 0)
		self.instructiontxt = "Now that you've got all your photos uploaded, let's make some desisions. For now you can only change the quality of your photos, but in the future you will be able to adjust other things as well, things like how the image will be created and how you would like repeated photos to be organized!\n\n"
		self.instructiontxt += "For quality, ratios are based off a 600 pixel wide photo, if your large image is smaller than that a lower ratio may be better to use, likewise if your photo is larger you may wish to use a custom size.\n"
		self.instructiontxt += "\nThe first thing you will see when you press the next button is a preview of your large image, once you close that window your collage will start building its self automatically.\n"
		self.instructiontxt += "\nWell what are you waiting for?! Get it overwith already!\n\n"
		self.instructiontxt += "Quality:"
		self._instructionLbl = Text(self._instructionPane, width = 65, height = 18, wrap = WORD)
		self._instructionLbl.insert("1.0", self.instructiontxt)
		self._instructionLbl.config(state = DISABLED)
		self._instructionLbl.grid(row = 0, column = 0)
		
		# Quality pane
		self.var = IntVar()
		self._selection = 0
		self._qltyPane = Frame(self)
		self._qltyPane1 = Frame(self)
		self._qltyPane.grid(row = 2, column = 0)
		self._qltyPane1.grid(row = 1, column = 0)
		self._highest = Radiobutton(self._qltyPane1, 
					text = "Highest\n1:1 ratio\nLarge photo visibility: 10\nSmall photo visibility: 0", 
					variable = self.var, value = 0)
		self._highest.grid(row = 0, column = 0)
		self._high = Radiobutton(self._qltyPane1,
					text = "High (recommended size)\n5:1 ratio\n128X128 photos\nLarge photo visibility: 7\nSmall photo visibility: 2,",
					variable = self.var, value = 128)
		self._high.grid(row = 0, column = 1)
		self._medium = Radiobutton(self._qltyPane1,
					text = "Medium\n10:1 ratio\n64X64 photos\nLarge photo visibility: 5\nSmall photo visibility: 4",
					variable = self.var, value = 64)
		self._medium.grid(row = 0, column = 2)
		self._low = Radiobutton(self._qltyPane,
					text = "Low\n20:1 ratio\n32X32 photos\nLarge photo visibility: 3\nSmall photo visibility: 7",
					variable = self.var, value = 32)
		self._low.grid(row = 0, column = 0)
		self._lowest = Radiobutton(self._qltyPane,
					text = "Lowest\n40:1 ratio\n16X16 photos\nLarge photo visibility: 1\nSmall photo visibility: 9",
					variable = self.var, value = 16)
		self._lowest.grid(row = 0, column = 1)
		self.txtvar = IntVar()
		self._customtxt = Entry(self._qltyPane, textvariable = self.txtvar, width = 3, text = 555)
		self._customBtn = Radiobutton(self._qltyPane, 
					text = "Custom: ", 
					variable = self.var, value = 5320)
		self._customlbl = Text(self._qltyPane, width = 12, height = 3)
		self._customlbl.insert("1.0", "\nX the same # of photos")
		self._customlbl.config(state=DISABLED)
		self._customBtn.grid(row = 0, column = 2)
		self._customtxt.grid(row = 0, column = 3)
		self._customlbl.grid(row = 0, column = 4)
		
		self.nextPane = Frame(self)
		self.nextPane.grid(row = 3, column = 0)
		self.nextBtn = Button(self.nextPane, text = "Next >>", command = self.next, width = 50)
		self.nextBtn.grid(row = 3, column = 0)
		
	def next(self):
		self.root.destroy()
		if self.var.get() == 5320:
			self._selection = self.txtvar.get()
		else:
			self._selection = self.var.get()
		from picAlgorithm import Picception
		Picception(self._minipics, self._bigpic, self._selection).create()
			
def main():
	picGUI().mainloop()
	
main()	
		
		
		
		
		
		
		